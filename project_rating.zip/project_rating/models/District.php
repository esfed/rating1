<?php
class District {
    private $conn;
    private $table_name = "districts";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function getAll() {
        $query = "SELECT * FROM districts ORDER BY name";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    public function getSchoolsCount($district_id) {
        $query = "SELECT COUNT(*) as count FROM schools WHERE district_id = :district_id AND is_active = TRUE";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':district_id', $district_id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['count'];
    }
}
?>