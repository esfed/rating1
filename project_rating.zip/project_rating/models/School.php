<?php
class School {
    private $conn;
    private $table_name = "schools";

    public function __construct($db) {
        $this->conn = $db;
    }

    // Получить все школы
    public function getAllSchools() {
        $query = "SELECT s.*, d.name as district_name 
                  FROM " . $this->table_name . " s 
                  LEFT JOIN districts d ON s.district_id = d.id 
                  ORDER BY s.name";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Получить школу по ID
    public function getSchoolById($id) {
        $query = "SELECT s.*, d.name as district_name 
                  FROM " . $this->table_name . " s 
                  LEFT JOIN districts d ON s.district_id = d.id 
                  WHERE s.id = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute(['id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Получить школы по району
    public function getSchoolsByDistrict($district_id) {
        $query = "SELECT s.*, d.name as district_name 
                  FROM " . $this->table_name . " s 
                  LEFT JOIN districts d ON s.district_id = d.id 
                  WHERE s.district_id = :district_id 
                  ORDER BY s.name";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute(['district_id' => $district_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Получить количество школ в районе
    public function getSchoolsCount($district_id) {
        $query = "SELECT COUNT(*) as count FROM " . $this->table_name . " WHERE district_id = :district_id";
        $stmt = $this->conn->prepare($query);
        $stmt->execute(['district_id' => $district_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'] ?? 0;
    }

    // Получить школы с рейтингом за учебный год
    public function getSchoolsWithRating($academic_year, $district_id = null) {
        $query = "SELECT s.*, d.name as district_name,
                         AVG(r.score) as average_score,
                         COUNT(r.id) as rating_count
                  FROM " . $this->table_name . " s
                  LEFT JOIN districts d ON s.district_id = d.id
                  LEFT JOIN ratings r ON s.id = r.school_id AND r.academic_year = :academic_year";
        
        if ($district_id) {
            $query .= " WHERE s.district_id = :district_id";
        }
        
        $query .= " GROUP BY s.id, s.name, d.name
                    ORDER BY average_score DESC";
        
        $stmt = $this->conn->prepare($query);
        
        $params = ['academic_year' => $academic_year];
        if ($district_id) {
            $params['district_id'] = $district_id;
        }
        
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Создать школу
    public function createSchool($data) {
        $query = "INSERT INTO " . $this->table_name . " 
                  (name, district_id, type, address, director, phone, email, website, description, created_at) 
                  VALUES 
                  (:name, :district_id, :type, :address, :director, :phone, :email, :website, :description, NOW())";
        
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([
            'name' => $data['name'],
            'district_id' => $data['district_id'],
            'type' => $data['type'],
            'address' => $data['address'],
            'director' => $data['director'],
            'phone' => $data['phone'],
            'email' => $data['email'],
            'website' => $data['website'],
            'description' => $data['description']
        ]);
    }

    // Обновить школу
    public function updateSchool($school_id, $data) {
        $query = "UPDATE " . $this->table_name . " SET 
                  name = :name, 
                  type = :type, 
                  address = :address, 
                  director = :director, 
                  phone = :phone, 
                  email = :email, 
                  website = :website, 
                  description = :description,
                  updated_at = NOW()
                  WHERE id = :school_id";
        
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([
            'name' => $data['name'],
            'type' => $data['type'],
            'address' => $data['address'],
            'director' => $data['director'],
            'phone' => $data['phone'],
            'email' => $data['email'],
            'website' => $data['website'],
            'description' => $data['description'],
            'school_id' => $school_id
        ]);
    }

    // Удалить школу
    public function deleteSchool($school_id) {
        // Сначала удаляем связанные оценки
        $delete_ratings = "DELETE FROM ratings WHERE school_id = :school_id";
        $stmt1 = $this->conn->prepare($delete_ratings);
        $stmt1->execute(['school_id' => $school_id]);
        
        // Затем удаляем школу
        $query = "DELETE FROM " . $this->table_name . " WHERE id = :school_id";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute(['school_id' => $school_id]);
    }

    // Поиск школ по названию
    public function searchSchools($search_term, $district_id = null) {
        $query = "SELECT s.*, d.name as district_name 
                  FROM " . $this->table_name . " s 
                  LEFT JOIN districts d ON s.district_id = d.id 
                  WHERE s.name LIKE :search_term";
        
        if ($district_id) {
            $query .= " AND s.district_id = :district_id";
        }
        
        $query .= " ORDER BY s.name";
        
        $stmt = $this->conn->prepare($query);
        
        $params = ['search_term' => '%' . $search_term . '%'];
        if ($district_id) {
            $params['district_id'] = $district_id;
        }
        
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Получить статистику по школам
    public function getSchoolStatistics($district_id = null) {
        $query = "SELECT 
                  COUNT(*) as total_schools,
                  COUNT(DISTINCT type) as unique_types,
                  AVG(LENGTH(description)) as avg_description_length
                  FROM " . $this->table_name;
        
        if ($district_id) {
            $query .= " WHERE district_id = :district_id";
        }
        
        $stmt = $this->conn->prepare($query);
        
        $params = [];
        if ($district_id) {
            $params['district_id'] = $district_id;
        }
        
        $stmt->execute($params);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Получить школы по типу
    public function getSchoolsByType($type, $district_id = null) {
        $query = "SELECT s.*, d.name as district_name 
                  FROM " . $this->table_name . " s 
                  LEFT JOIN districts d ON s.district_id = d.id 
                  WHERE s.type = :type";
        
        if ($district_id) {
            $query .= " AND s.district_id = :district_id";
        }
        
        $query .= " ORDER BY s.name";
        
        $stmt = $this->conn->prepare($query);
        
        $params = ['type' => $type];
        if ($district_id) {
            $params['district_id'] = $district_id;
        }
        
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Проверить существование школы
    public function schoolExists($name, $district_id, $exclude_id = null) {
        $query = "SELECT COUNT(*) as count FROM " . $this->table_name . " 
                  WHERE name = :name AND district_id = :district_id";
        
        if ($exclude_id) {
            $query .= " AND id != :exclude_id";
        }
        
        $stmt = $this->conn->prepare($query);
        
        $params = [
            'name' => $name,
            'district_id' => $district_id
        ];
        
        if ($exclude_id) {
            $params['exclude_id'] = $exclude_id;
        }
        
        $stmt->execute($params);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'] > 0;
    }

    // Получить последние добавленные школы
    public function getRecentSchools($limit = 10, $district_id = null) {
        $query = "SELECT s.*, d.name as district_name 
                  FROM " . $this->table_name . " s 
                  LEFT JOIN districts d ON s.district_id = d.id";
        
        if ($district_id) {
            $query .= " WHERE s.district_id = :district_id";
        }
        
        $query .= " ORDER BY s.created_at DESC LIMIT :limit";
        
        $stmt = $this->conn->prepare($query);
        
        $params = ['limit' => $limit];
        if ($district_id) {
            $params['district_id'] = $district_id;
        }
        
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Обновить контактную информацию
    public function updateContactInfo($school_id, $contact_data) {
        $query = "UPDATE " . $this->table_name . " SET 
                  director = :director, 
                  phone = :phone, 
                  email = :email, 
                  website = :website,
                  updated_at = NOW()
                  WHERE id = :school_id";
        
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([
            'director' => $contact_data['director'],
            'phone' => $contact_data['phone'],
            'email' => $contact_data['email'],
            'website' => $contact_data['website'],
            'school_id' => $school_id
        ]);
    }

    // Получить школы без оценок за учебный год
    public function getSchoolsWithoutRatings($academic_year, $district_id = null) {
        $query = "SELECT s.*, d.name as district_name
                  FROM " . $this->table_name . " s
                  LEFT JOIN districts d ON s.district_id = d.id
                  WHERE s.id NOT IN (
                      SELECT DISTINCT school_id 
                      FROM ratings 
                      WHERE academic_year = :academic_year
                  )";
        
        if ($district_id) {
            $query .= " AND s.district_id = :district_id";
        }
        
        $query .= " ORDER BY s.name";
        
        $stmt = $this->conn->prepare($query);
        
        $params = ['academic_year' => $academic_year];
        if ($district_id) {
            $params['district_id'] = $district_id;
        }
        
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    // Добавляем в класс School
/**
 * Получить статистику по району
 */
public function getDistrictStatistics($district_id) {
    $query = "SELECT 
                COUNT(*) as total_schools,
                COUNT(DISTINCT type) as school_types,
                AVG(LENGTH(description)) as avg_description_length
              FROM " . $this->table_name . " 
              WHERE district_id = :district_id";
    
    $stmt = $this->conn->prepare($query);
    $stmt->execute(['district_id' => $district_id]);
    
    return $stmt->fetch(PDO::FETCH_ASSOC);
}
}
?>