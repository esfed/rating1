<?php
class Criteria {
    private $conn;
    private $table_name = "criteria";

    public function __construct($db) {
        $this->conn = $db;
    }

    // Получить все критерии
    public function getAllCriteria() {
        $query = "SELECT * FROM " . $this->table_name . " ORDER BY name";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Получить критерий по ID
    public function getCriteriaById($id) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->execute(['id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Получить критерии с статистикой
    public function getCriteriaWithStats($academic_year, $district_id) {
        $query = "SELECT c.*, 
                         COUNT(r.id) as rating_count,
                         AVG(r.score) as avg_score
                  FROM " . $this->table_name . " c
                  LEFT JOIN ratings r ON c.id = r.criteria_id 
                  LEFT JOIN schools s ON r.school_id = s.id
                  WHERE r.academic_year = :academic_year 
                  AND s.district_id = :district_id
                  GROUP BY c.id
                  ORDER BY c.name";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute([
            'academic_year' => $academic_year,
            'district_id' => $district_id
        ]);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>