<?php
class Rating {
    private $conn;
    private $table_name = "ratings";

    public function __construct($db) {
        $this->conn = $db;
    }

    // Получить общий рейтинг школ
    public function getOverallRating($filters) {
        $query = "SELECT s.id, s.name as school_name, d.name as district_name,
                         AVG(r.score) as average_score,
                         COUNT(r.id) as rating_count,
                         MAX(r.created_at) as last_rating_date
                  FROM schools s
                  LEFT JOIN districts d ON s.district_id = d.id
                  LEFT JOIN ratings r ON s.id = r.school_id 
                    AND r.academic_year = :academic_year
                  WHERE s.district_id = :district_id
                  GROUP BY s.id, s.name, d.name
                  HAVING COUNT(r.id) > 0
                  ORDER BY average_score DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute([
            'academic_year' => $filters['academic_year'],
            'district_id' => $filters['district_id']
        ]);
        
        return $stmt;
    }

    // Добавить оценку
    public function addRating($data) {
        $query = "INSERT INTO " . $this->table_name . " 
                  (school_id, criteria_id, academic_year, score, comments, assessed_by, created_at) 
                  VALUES 
                  (:school_id, :criteria_id, :academic_year, :score, :comments, :assessed_by, NOW())";
        
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([
            'school_id' => $data['school_id'],
            'criteria_id' => $data['criteria_id'],
            'academic_year' => $data['academic_year'],
            'score' => $data['score'],
            'comments' => $data['comments'],
            'assessed_by' => $data['assessed_by']
        ]);
    }

    // Получить оценки школы
    public function getSchoolRatings($school_id, $academic_year) {
        $query = "SELECT r.*, c.name as criteria_name, c.description as criteria_description,
                         c.max_score as criteria_max_score
                  FROM " . $this->table_name . " r 
                  JOIN criteria c ON r.criteria_id = c.id 
                  WHERE r.school_id = :school_id AND r.academic_year = :academic_year
                  ORDER BY c.name";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute([
            'school_id' => $school_id,
            'academic_year' => $academic_year
        ]);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Получить оценку по ID
    public function getRatingById($rating_id) {
        $query = "SELECT r.*, s.name as school_name, c.name as criteria_name,
                         c.description as criteria_description
                  FROM " . $this->table_name . " r
                  JOIN schools s ON r.school_id = s.id
                  JOIN criteria c ON r.criteria_id = c.id
                  WHERE r.id = :rating_id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute(['rating_id' => $rating_id]);
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Обновить оценку
    public function updateRating($rating_id, $data) {
        $query = "UPDATE " . $this->table_name . " 
                  SET score = :score, comments = :comments, updated_at = NOW() 
                  WHERE id = :rating_id";
        
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([
            'score' => $data['score'],
            'comments' => $data['comments'],
            'rating_id' => $rating_id
        ]);
    }

    // Удалить оценку
    public function deleteRating($rating_id) {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = :rating_id";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute(['rating_id' => $rating_id]);
    }

    // Получить статистику по критериям
    public function getCriteriaStatistics($filters) {
        $query = "SELECT c.id, c.name as criterion_name, 
                         AVG(r.score) as avg_score,
                         MAX(r.score) as max_score,
                         MIN(r.score) as min_score,
                         COUNT(r.id) as rating_count,
                         c.max_score as criteria_max
                  FROM criteria c
                  LEFT JOIN ratings r ON c.id = r.criteria_id 
                    AND r.academic_year = :academic_year
                  LEFT JOIN schools s ON r.school_id = s.id 
                    AND s.district_id = :district_id
                  GROUP BY c.id, c.name
                  ORDER BY c.name";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute([
            'academic_year' => $filters['academic_year'],
            'district_id' => $filters['district_id']
        ]);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Получить данные для экспорта
    public function getExportData($filters) {
        $query = "SELECT s.name as school_name, s.type as school_type,
                         AVG(r.score) as average_score,
                         COUNT(r.id) as rating_count,
                         MAX(r.created_at) as last_rating_date
                  FROM schools s
                  LEFT JOIN ratings r ON s.id = r.school_id 
                    AND r.academic_year = :academic_year
                  WHERE s.district_id = :district_id
                  GROUP BY s.id, s.name, s.type
                  HAVING COUNT(r.id) > 0
                  ORDER BY average_score DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute([
            'academic_year' => $filters['academic_year'],
            'district_id' => $filters['district_id']
        ]);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Импорт из Excel
    public function importFromExcel($filepath, $file_ext) {
        // В реальной реализации здесь будет парсинг Excel файла
        // Сейчас возвращаем заглушку для демонстрации
        return [
            'imported' => rand(5, 20),
            'skipped' => rand(0, 5),
            'schools_count' => rand(3, 8),
            'criteria_count' => rand(4, 6)
        ];
    }

    // Получить детальную статистику по школе
    public function getSchoolDetailedStats($school_id, $academic_year) {
        $query = "SELECT c.name as criteria_name,
                         AVG(r.score) as average_score,
                         COUNT(r.id) as rating_count,
                         MAX(r.score) as max_score,
                         MIN(r.score) as min_score
                  FROM criteria c
                  LEFT JOIN ratings r ON c.id = r.criteria_id 
                    AND r.school_id = :school_id 
                    AND r.academic_year = :academic_year
                  GROUP BY c.id, c.name
                  ORDER BY c.name";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute([
            'school_id' => $school_id,
            'academic_year' => $academic_year
        ]);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Получить историю оценок школы
    public function getSchoolRatingHistory($school_id, $criteria_id = null) {
        $query = "SELECT r.*, c.name as criteria_name, ay.academic_year
                  FROM " . $this->table_name . " r
                  JOIN criteria c ON r.criteria_id = c.id
                  JOIN (SELECT DISTINCT academic_year FROM ratings) ay ON r.academic_year = ay.academic_year
                  WHERE r.school_id = :school_id";
        
        if ($criteria_id) {
            $query .= " AND r.criteria_id = :criteria_id";
        }
        
        $query .= " ORDER BY r.academic_year DESC, c.name";
        
        $stmt = $this->conn->prepare($query);
        
        $params = ['school_id' => $school_id];
        if ($criteria_id) {
            $params['criteria_id'] = $criteria_id;
        }
        
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Проверить существование оценки
    public function ratingExists($school_id, $criteria_id, $academic_year) {
        $query = "SELECT COUNT(*) as count FROM " . $this->table_name . " 
                  WHERE school_id = :school_id 
                  AND criteria_id = :criteria_id 
                  AND academic_year = :academic_year";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute([
            'school_id' => $school_id,
            'criteria_id' => $criteria_id,
            'academic_year' => $academic_year
        ]);
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'] > 0;
    }

    // Получить оценки по критерию
    public function getRatingsByCriteria($criteria_id, $academic_year, $district_id = null) {
        $query = "SELECT r.*, s.name as school_name, d.name as district_name
                  FROM " . $this->table_name . " r
                  JOIN schools s ON r.school_id = s.id
                  JOIN districts d ON s.district_id = d.id
                  WHERE r.criteria_id = :criteria_id 
                  AND r.academic_year = :academic_year";
        
        if ($district_id) {
            $query .= " AND s.district_id = :district_id";
        }
        
        $query .= " ORDER BY r.score DESC";
        
        $stmt = $this->conn->prepare($query);
        
        $params = [
            'criteria_id' => $criteria_id,
            'academic_year' => $academic_year
        ];
        
        if ($district_id) {
            $params['district_id'] = $district_id;
        }
        
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Получить средний балл по району
    public function getDistrictAverage($district_id, $academic_year) {
        $query = "SELECT AVG(r.score) as district_average,
                         COUNT(r.id) as total_ratings,
                         COUNT(DISTINCT r.school_id) as rated_schools
                  FROM " . $this->table_name . " r
                  JOIN schools s ON r.school_id = s.id
                  WHERE s.district_id = :district_id 
                  AND r.academic_year = :academic_year";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute([
            'district_id' => $district_id,
            'academic_year' => $academic_year
        ]);
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Получить топ школ по критерию
    public function getTopSchoolsByCriteria($criteria_id, $academic_year, $limit = 10, $district_id = null) {
        $query = "SELECT s.name as school_name, d.name as district_name,
                         r.score, r.comments, r.created_at
                  FROM " . $this->table_name . " r
                  JOIN schools s ON r.school_id = s.id
                  JOIN districts d ON s.district_id = d.id
                  WHERE r.criteria_id = :criteria_id 
                  AND r.academic_year = :academic_year";
        
        if ($district_id) {
            $query .= " AND s.district_id = :district_id";
        }
        
        $query .= " ORDER BY r.score DESC LIMIT :limit";
        
        $stmt = $this->conn->prepare($query);
        
        $params = [
            'criteria_id' => $criteria_id,
            'academic_year' => $academic_year,
            'limit' => $limit
        ];
        
        if ($district_id) {
            $params['district_id'] = $district_id;
        }
        
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Получить распределение оценок
    public function getScoreDistribution($academic_year, $district_id = null) {
        $query = "SELECT 
                    CASE 
                        WHEN score >= 90 THEN 'Отлично (90-100)'
                        WHEN score >= 75 THEN 'Хорошо (75-89)'
                        WHEN score >= 60 THEN 'Удовлетворительно (60-74)'
                        ELSE 'Неудовлетворительно (<60)'
                    END as score_range,
                    COUNT(*) as count
                  FROM " . $this->table_name . " r
                  JOIN schools s ON r.school_id = s.id
                  WHERE r.academic_year = :academic_year";
        
        if ($district_id) {
            $query .= " AND s.district_id = :district_id";
        }
        
        $query .= " GROUP BY score_range
                    ORDER BY MIN(score) DESC";
        
        $stmt = $this->conn->prepare($query);
        
        $params = ['academic_year' => $academic_year];
        if ($district_id) {
            $params['district_id'] = $district_id;
        }
        
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Получить последние добавленные оценки
    public function getRecentRatings($limit = 10, $district_id = null) {
        $query = "SELECT r.*, s.name as school_name, c.name as criteria_name
                  FROM " . $this->table_name . " r
                  JOIN schools s ON r.school_id = s.id
                  JOIN criteria c ON r.criteria_id = c.id";
        
        if ($district_id) {
            $query .= " WHERE s.district_id = :district_id";
        }
        
        $query .= " ORDER BY r.created_at DESC LIMIT :limit";
        
        $stmt = $this->conn->prepare($query);
        
        $params = ['limit' => $limit];
        if ($district_id) {
            $params['district_id'] = $district_id;
        }
        
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Получить оценки за период
    public function getRatingsByPeriod($start_date, $end_date, $district_id = null) {
        $query = "SELECT r.*, s.name as school_name, c.name as criteria_name
                  FROM " . $this->table_name . " r
                  JOIN schools s ON r.school_id = s.id
                  JOIN criteria c ON r.criteria_id = c.id
                  WHERE r.created_at BETWEEN :start_date AND :end_date";
        
        if ($district_id) {
            $query .= " AND s.district_id = :district_id";
        }
        
        $query .= " ORDER BY r.created_at DESC";
        
        $stmt = $this->conn->prepare($query);
        
        $params = [
            'start_date' => $start_date,
            'end_date' => $end_date
        ];
        
        if ($district_id) {
            $params['district_id'] = $district_id;
        }
        
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Обновить несколько оценок
    public function updateMultipleRatings($ratings_data) {
        $this->conn->beginTransaction();
        
        try {
            $query = "UPDATE " . $this->table_name . " 
                      SET score = :score, comments = :comments, updated_at = NOW() 
                      WHERE id = :rating_id";
            
            $stmt = $this->conn->prepare($query);
            
            foreach ($ratings_data as $rating) {
                $stmt->execute([
                    'score' => $rating['score'],
                    'comments' => $rating['comments'],
                    'rating_id' => $rating['id']
                ]);
            }
            
            $this->conn->commit();
            return true;
            
        } catch (Exception $e) {
            $this->conn->rollBack();
            return false;
        }
    }

    // Получить общую статистику
    public function getGeneralStatistics($academic_year, $district_id = null) {
        $query = "SELECT 
                    COUNT(DISTINCT r.school_id) as rated_schools_count,
                    COUNT(r.id) as total_ratings,
                    AVG(r.score) as overall_average,
                    MAX(r.score) as highest_score,
                    MIN(r.score) as lowest_score,
                    COUNT(DISTINCT r.criteria_id) as used_criteria_count
                  FROM " . $this->table_name . " r
                  JOIN schools s ON r.school_id = s.id
                  WHERE r.academic_year = :academic_year";
        
        if ($district_id) {
            $query .= " AND s.district_id = :district_id";
        }
        
        $stmt = $this->conn->prepare($query);
        
        $params = ['academic_year' => $academic_year];
        if ($district_id) {
            $params['district_id'] = $district_id;
        }
        
        $stmt->execute($params);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    // Добавляем этот метод в класс Rating
// Добавляем эти методы в класс Rating

/**
 * Получить распределение оценок по диапазонам
 */
public function getRatingDistribution($academic_year, $district_id = null) {
    $query = "SELECT 
                CASE 
                    WHEN r.score >= 90 THEN 'Отлично (90-100)'
                    WHEN r.score >= 75 THEN 'Хорошо (75-89)'
                    WHEN r.score >= 60 THEN 'Удовлетворительно (60-74)'
                    ELSE 'Неудовлетворительно (<60)'
                END as score_range,
                COUNT(DISTINCT r.school_id) as count
              FROM " . $this->table_name . " r
              JOIN schools s ON r.school_id = s.id
              WHERE r.academic_year = :academic_year";
    
    if ($district_id) {
        $query .= " AND s.district_id = :district_id";
    }
    
    $query .= " GROUP BY score_range
                ORDER BY MIN(r.score) DESC";
    
    $stmt = $this->conn->prepare($query);
    
    $params = ['academic_year' => $academic_year];
    if ($district_id) {
        $params['district_id'] = $district_id;
    }
    
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Получить средние баллы по району
 */
public function getDistrictAverageScores($district_id, $academic_year) {
    $query = "SELECT 
                c.name as criteria_name,
                AVG(r.score) as average_score,
                COUNT(r.id) as rating_count
              FROM " . $this->table_name . " r
              JOIN schools s ON r.school_id = s.id
              JOIN criteria c ON r.criteria_id = c.id
              WHERE s.district_id = :district_id 
              AND r.academic_year = :academic_year
              GROUP BY c.id, c.name
              ORDER BY c.name";
    
    $stmt = $this->conn->prepare($query);
    $stmt->execute([
        'district_id' => $district_id,
        'academic_year' => $academic_year
    ]);
    
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Получить самые улучшившиеся школы
 */
public function getMostImprovedSchools($academic_year, $district_id = null, $limit = 5) {
    // Временная заглушка - в реальной системе нужно сравнивать с предыдущим годом
    $query = "SELECT 
                s.id,
                s.name as school_name,
                AVG(r.score) as current_score,
                (AVG(r.score) - 70) as improvement  -- Заглушка для демонстрации
              FROM " . $this->table_name . " r
              JOIN schools s ON r.school_id = s.id
              WHERE r.academic_year = :academic_year";
    
    if ($district_id) {
        $query .= " AND s.district_id = :district_id";
    }
    
    $query .= " GROUP BY s.id, s.name
                ORDER BY improvement DESC
                LIMIT :limit";
    
    $stmt = $this->conn->prepare($query);
    
    $params = [
        'academic_year' => $academic_year,
        'limit' => $limit
    ];
    
    if ($district_id) {
        $params['district_id'] = $district_id;
    }
    
    $stmt->execute($params);
    return $stmt;
}

/**
 * Получить оценки школы по критериям
 */
public function getSchoolScores($school_id, $academic_year) {
    $query = "SELECT 
                c.name as criteria_name,
                r.score
              FROM " . $this->table_name . " r
              JOIN criteria c ON r.criteria_id = c.id
              WHERE r.school_id = :school_id 
              AND r.academic_year = :academic_year";
    
    $stmt = $this->conn->prepare($query);
    $stmt->execute([
        'school_id' => $school_id,
        'academic_year' => $academic_year
    ]);
    
    $scores = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $scores[$row['criteria_name']] = $row['score'];
    }
    
    return $scores;
}
}
?>