<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="dashboard.php">
            <i class="fas fa-school me-2"></i>Рейтинг школ
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link" href="dashboard.php"><i class="fas fa-tachometer-alt me-1"></i>Главная</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="criteria_charts.php"><i class="fas fa-chart-bar me-1"></i>Аналитика</a>
                </li>
                <?php if ($_SESSION['user_role'] === 'admin'): ?>
                <li class="nav-item">
                    <a class="nav-link" href="add_school.php"><i class="fas fa-plus me-1"></i>Добавить школу</a>
                </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link" href="add_rating.php"><i class="fas fa-edit me-1"></i>Ввести данные</a>
                </li>
            </ul>
            <ul class="navbar-nav">
                <li class="nav-item">
                    <span class="navbar-text me-3">
                        <i class="fas fa-user me-1"></i><?= $_SESSION['full_name'] ?> (<?= $_SESSION['user_role'] ?>)
                    </span>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt me-1"></i>Выйти</a>
                </li>
            </ul>
        </div>
    </div>
</nav>