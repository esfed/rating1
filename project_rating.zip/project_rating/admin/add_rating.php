<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Проверка авторизации
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

include_once '../config/database.php';
include_once '../models/School.php';
include_once '../models/Rating.php';
include_once '../models/Criteria.php';

$success = null;
$error = null;
$schools = [];
$criteria_list = [];

try {
    $database = new Database();
    $db = $database->getConnection();
    
    $school = new School($db);
    $rating = new Rating($db);
    $criteria = new Criteria($db);

    // Получаем список школ и критериев
    $schools = $school->getAllSchools();
    $criteria_list = $criteria->getAllCriteria();

    // Обработка формы добавления оценки
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $school_id = $_POST['school_id'] ?? '';
        $academic_year = $_POST['academic_year'] ?? '2025-2026';
        $scores = $_POST['scores'] ?? [];
        $comments = $_POST['comments'] ?? [];

        // Валидация
        if (empty($school_id)) {
            $error = "Выберите школу для оценки";
        } elseif (empty($scores)) {
            $error = "Заполните оценки хотя бы по одному критерию";
        } else {
            // Добавляем оценки
            $added_count = 0;
            
            foreach ($scores as $criteria_id => $score) {
                if (!empty($score) && $score >= 0 && $score <= 100) {
                    $comment = $comments[$criteria_id] ?? '';
                    
                    $result = $rating->addRating([
                        'school_id' => $school_id,
                        'criteria_id' => $criteria_id,
                        'academic_year' => $academic_year,
                        'score' => $score,
                        'comments' => $comment,
                        'assessed_by' => $_SESSION['admin_id'] ?? 1
                    ]);
                    
                    if ($result) {
                        $added_count++;
                    }
                }
            }
            
            if ($added_count > 0) {
                $success = "Успешно добавлено $added_count оценок!";
                // Очищаем поля формы
                $_POST = [];
            } else {
                $error = "Не удалось добавить оценки. Проверьте введенные данные.";
            }
        }
    }

} catch (Exception $e) {
    $error = "Ошибка: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Добавить оценку - Панель управления</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .criteria-card {
            border-left: 4px solid #4e73df;
            margin-bottom: 1rem;
        }
        .criteria-card .card-header {
            background-color: #f8f9fa;
            border-bottom: 1px solid #dee2e6;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-edit me-2"></i>Добавить оценку
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-arrow-left me-1"></i>Назад в панель
                </a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <?php if ($success): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <i class="fas fa-check-circle me-2"></i><?= $success ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <i class="fas fa-exclamation-triangle me-2"></i><?= $error ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white">
                        <h4 class="mb-0">
                            <i class="fas fa-chart-line me-2 text-primary"></i>Добавление оценок школы
                        </h4>
                    </div>
                    <div class="card-body">
                        <form method="POST" id="ratingForm">
                            <div class="row g-3 mb-4">
                                <!-- Выбор школы и учебного года -->
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Образовательное учреждение <span class="text-danger">*</span></label>
                                    <select name="school_id" class="form-select" required>
                                        <option value="">Выберите школу...</option>
                                        <?php foreach ($schools as $school_item): ?>
                                            <option value="<?= $school_item['id'] ?>" 
                                                <?= ($_POST['school_id'] ?? '') == $school_item['id'] ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($school_item['name']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Учебный год <span class="text-danger">*</span></label>
                                    <select name="academic_year" class="form-select" required>
                                        <option value="2024-2025" <?= ($_POST['academic_year'] ?? '2025-2026') == '2024-2025' ? 'selected' : '' ?>>2024-2025</option>
                                        <option value="2025-2026" <?= ($_POST['academic_year'] ?? '2025-2026') == '2025-2026' ? 'selected' : '' ?>>2025-2026</option>
                                    </select>
                                </div>
                            </div>

                            <!-- Критерии оценки -->
                            <h5 class="mb-3">
                                <i class="fas fa-list-alt me-2 text-warning"></i>Критерии оценки
                            </h5>

                            <?php if (!empty($criteria_list)): ?>
                                <div class="row g-3">
                                    <?php foreach ($criteria_list as $criterion): ?>
                                        <div class="col-12">
                                            <div class="card criteria-card">
                                                <div class="card-header">
                                                    <h6 class="mb-0">
                                                        <?= htmlspecialchars($criterion['name']) ?>
                                                        <?php if ($criterion['max_score']): ?>
                                                            <small class="text-muted">(максимум: <?= $criterion['max_score'] ?> баллов)</small>
                                                        <?php endif; ?>
                                                    </h6>
                                                </div>
                                                <div class="card-body">
                                                    <?php if (!empty($criterion['description'])): ?>
                                                        <p class="text-muted mb-3"><?= htmlspecialchars($criterion['description']) ?></p>
                                                    <?php endif; ?>
                                                    
                                                    <div class="row g-3">
                                                        <div class="col-md-6">
                                                            <label class="form-label fw-semibold">Балл (0-100)</label>
                                                            <input type="number" 
                                                                   name="scores[<?= $criterion['id'] ?>]" 
                                                                   class="form-control score-input" 
                                                                   min="0" max="100" step="0.1"
                                                                   value="<?= $_POST['scores'][$criterion['id']] ?? '' ?>"
                                                                   placeholder="Введите балл">
                                                        </div>
                                                        <div class="col-md-6">
                                                            <label class="form-label fw-semibold">Комментарий (необязательно)</label>
                                                            <input type="text" 
                                                                   name="comments[<?= $criterion['id'] ?>]" 
                                                                   class="form-control" 
                                                                   value="<?= htmlspecialchars($_POST['comments'][$criterion['id']] ?? '') ?>"
                                                                   placeholder="Комментарий к оценке"
                                                                   maxlength="255">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-warning">
                                    <i class="fas fa-exclamation-triangle me-2"></i>
                                    Критерии оценки не найдены. Обратитесь к администратору.
                                </div>
                            <?php endif; ?>

                            <!-- Кнопки -->
                            <div class="row mt-4">
                                <div class="col-12">
                                    <hr>
                                    <div class="d-flex justify-content-between">
                                        <button type="submit" class="btn btn-primary btn-lg">
                                            <i class="fas fa-save me-2"></i>Сохранить оценки
                                        </button>
                                        <div>
                                            <a href="import_excel.php" class="btn btn-success btn-lg me-2">
                                                <i class="fas fa-file-import me-2"></i>Импорт из Excel
                                            </a>
                                            <a href="dashboard.php" class="btn btn-secondary btn-lg">
                                                <i class="fas fa-times me-2"></i>Отмена
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Подсказки -->
                <div class="card border-0 shadow-sm mt-4">
                    <div class="card-header bg-white">
                        <h5 class="mb-0">
                            <i class="fas fa-info-circle me-2 text-info"></i>Инструкция
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h6>Обязательные поля:</h6>
                                <ul class="mb-0">
                                    <li>Выбор школы</li>
                                    <li>Учебный год</li>
                                    <li>Хотя бы одна оценка</li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <h6>Рекомендации:</h6>
                                <ul class="mb-0">
                                    <li>Оценки должны быть в диапазоне 0-100</li>
                                    <li>Можно использовать дробные числа (например, 85.5)</li>
                                    <li>Комментарии помогают понять причину оценки</li>
                                    <li>Для массового ввода используйте импорт Excel</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer mt-5 py-4" style="background: #343a40; color: white;">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <small class="d-block">МКУ "Управление образования Нюрбинского района"</small>
                    <small class="text-muted">Система оценки образовательных учреждений</small>
                </div>
                <div class="col-md-6 text-md-end">
                    <small>
                        <i class="fas fa-copyright me-1"></i> Все права защищены 
                        <i class="fas fa-shield-alt mx-1"></i> 2025 год 
                        by Эдуард Федоров
                    </small>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Валидация формы
        document.getElementById('ratingForm').addEventListener('submit', function(e) {
            const schoolId = this.querySelector('select[name="school_id"]').value;
            const scoreInputs = this.querySelectorAll('.score-input');
            let hasScore = false;
            
            // Проверяем, есть ли хотя бы одна оценка
            scoreInputs.forEach(input => {
                if (input.value.trim() !== '') {
                    hasScore = true;
                }
            });
            
            if (!schoolId) {
                e.preventDefault();
                alert('Пожалуйста, выберите школу');
                return false;
            }
            
            if (!hasScore) {
                e.preventDefault();
                alert('Пожалуйста, заполните хотя бы одну оценку');
                return false;
            }
            
            // Проверяем корректность оценок
            let validScores = true;
            scoreInputs.forEach(input => {
                if (input.value.trim() !== '') {
                    const score = parseFloat(input.value);
                    if (isNaN(score) || score < 0 || score > 100) {
                        validScores = false;
                        input.classList.add('is-invalid');
                    } else {
                        input.classList.remove('is-invalid');
                    }
                }
            });
            
            if (!validScores) {
                e.preventDefault();
                alert('Оценки должны быть числами от 0 до 100');
                return false;
            }
            
            // Показываем индикатор загрузки
            const submitBtn = this.querySelector('button[type="submit"]');
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Сохранение...';
            submitBtn.disabled = true;
        });

        // Валидация в реальном времени
        document.querySelectorAll('.score-input').forEach(input => {
            input.addEventListener('blur', function() {
                const value = this.value.trim();
                if (value !== '') {
                    const score = parseFloat(value);
                    if (isNaN(score) || score < 0 || score > 100) {
                        this.classList.add('is-invalid');
                    } else {
                        this.classList.remove('is-invalid');
                    }
                }
            });
        });
    </script>
</body>
</html>