<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Проверка авторизации
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

include_once '../config/database.php';
include_once '../models/Rating.php';
include_once '../models/School.php';
include_once '../models/Criteria.php';

$rating_id = $_GET['id'] ?? '';
$rating_data = null;
$school_data = null;
$criteria_data = null;
$success = null;
$error = null;

try {
    $database = new Database();
    $db = $database->getConnection();
    
    $rating = new Rating($db);
    $school = new School($db);
    $criteria = new Criteria($db);

    // Получаем данные оценки
    if ($rating_id) {
        $rating_data = $rating->getRatingById($rating_id);
    }

    // Если оценка не найдена
    if (!$rating_data) {
        header("Location: dashboard.php");
        exit;
    }

    // Получаем данные школы и критерия
    $school_data = $school->getSchoolById($rating_data['school_id']);
    $criteria_data = $criteria->getCriteriaById($rating_data['criteria_id']);

    // Обработка формы обновления
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $score = $_POST['score'] ?? '';
        $comments = $_POST['comments'] ?? '';

        // Валидация
        if (empty($score) || !is_numeric($score)) {
            $error = "Введите корректный балл";
        } elseif ($score < 0 || $score > 100) {
            $error = "Балл должен быть в диапазоне от 0 до 100";
        } else {
            // Обновляем оценку
            $result = $rating->updateRating($rating_id, [
                'score' => $score,
                'comments' => $comments
            ]);

            if ($result) {
                $success = "Оценка успешно обновлена!";
                // Обновляем данные оценки
                $rating_data = $rating->getRatingById($rating_id);
            } else {
                $error = "Ошибка при обновлении оценки";
            }
        }
    }

} catch (Exception $e) {
    $error = "Ошибка: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Редактировать оценку - Панель управления</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-edit me-2"></i>Редактировать оценку
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="school_ratings.php?id=<?= $rating_data['school_id'] ?? '' ?>">
                    <i class="fas fa-arrow-left me-1"></i>Назад к оценкам
                </a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <?php if ($success): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <i class="fas fa-check-circle me-2"></i><?= $success ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <i class="fas fa-exclamation-triangle me-2"></i><?= $error ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white">
                        <h4 class="mb-0">
                            <i class="fas fa-chart-line me-2 text-primary"></i>Редактирование оценки
                        </h4>
                    </div>
                    <div class="card-body">
                        <!-- Информация об оценке -->
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <div class="border rounded p-3 bg-light">
                                    <h6 class="text-muted mb-2">Школа:</h6>
                                    <h5 class="text-primary mb-0">
                                        <i class="fas fa-school me-2"></i>
                                        <?= htmlspecialchars($school_data['name'] ?? '') ?>
                                    </h5>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="border rounded p-3 bg-light">
                                    <h6 class="text-muted mb-2">Критерий:</h6>
                                    <h5 class="text-success mb-0">
                                        <i class="fas fa-list-alt me-2"></i>
                                        <?= htmlspecialchars($criteria_data['name'] ?? '') ?>
                                    </h5>
                                </div>
                            </div>
                        </div>

                        <form method="POST" id="ratingForm">
                            <div class="row g-3">
                                <!-- Балл -->
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Балл <span class="text-danger">*</span></label>
                                    <input type="number" name="score" class="form-control" 
                                           value="<?= htmlspecialchars($rating_data['score']) ?>" 
                                           min="0" max="100" step="0.1" required>
                                    <div class="form-text">
                                        Введите число от 0 до 100. Можно использовать десятичные дроби.
                                    </div>
                                </div>

                                <!-- Учебный год (только чтение) -->
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Учебный год</label>
                                    <input type="text" class="form-control" 
                                           value="<?= htmlspecialchars($rating_data['academic_year']) ?>" 
                                           readonly>
                                    <div class="form-text">Учебный год нельзя изменить</div>
                                </div>

                                <!-- Комментарий -->
                                <div class="col-12">
                                    <label class="form-label fw-semibold">Комментарий</label>
                                    <textarea name="comments" class="form-control" rows="4" 
                                              placeholder="Комментарий к оценке..."
                                              maxlength="500"><?= htmlspecialchars($rating_data['comments'] ?? '') ?></textarea>
                                    <div class="form-text">Максимум 500 символов</div>
                                </div>

                                <!-- Информация о критерии -->
                                <?php if (!empty($criteria_data['description'])): ?>
                                    <div class="col-12">
                                        <div class="alert alert-info">
                                            <h6 class="alert-heading">
                                                <i class="fas fa-info-circle me-2"></i>Описание критерия:
                                            </h6>
                                            <p class="mb-0"><?= htmlspecialchars($criteria_data['description']) ?></p>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <!-- Дополнительная информация -->
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Дата создания</label>
                                    <input type="text" class="form-control" 
                                           value="<?= date('d.m.Y H:i', strtotime($rating_data['created_at'])) ?>" 
                                           readonly>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Последнее обновление</label>
                                    <input type="text" class="form-control" 
                                           value="<?= date('d.m.Y H:i', strtotime($rating_data['updated_at'] ?? $rating_data['created_at'])) ?>" 
                                           readonly>
                                </div>

                                <!-- Кнопки -->
                                <div class="col-12">
                                    <hr>
                                    <div class="d-flex justify-content-between">
                                        <button type="submit" class="btn btn-primary btn-lg">
                                            <i class="fas fa-save me-2"></i>Сохранить изменения
                                        </button>
                                        <div>
                                            <a href="school_ratings.php?id=<?= $rating_data['school_id'] ?>" class="btn btn-secondary btn-lg me-2">
                                                <i class="fas fa-times me-2"></i>Отмена
                                            </a>
                                            <a href="../school_detail.php?id=<?= $rating_data['school_id'] ?>" class="btn btn-outline-primary btn-lg" target="_blank">
                                                <i class="fas fa-eye me-2"></i>Просмотр школы
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Быстрые действия -->
                <div class="card border-0 shadow-sm mt-4">
                    <div class="card-header bg-white">
                        <h5 class="mb-0">
                            <i class="fas fa-bolt me-2 text-warning"></i>Быстрые действия
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-4">
                                <a href="school_ratings.php?id=<?= $rating_data['school_id'] ?>" class="btn btn-outline-info w-100">
                                    <i class="fas fa-list me-2"></i>Все оценки школы
                                </a>
                            </div>
                            <div class="col-md-4">
                                <a href="add_rating.php?school_id=<?= $rating_data['school_id'] ?>" class="btn btn-outline-primary w-100">
                                    <i class="fas fa-plus me-2"></i>Добавить оценку
                                </a>
                            </div>
                            <div class="col-md-4">
                                <a href="edit_school.php?id=<?= $rating_data['school_id'] ?>" class="btn btn-outline-warning w-100">
                                    <i class="fas fa-edit me-2"></i>Редактировать школу
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer mt-5 py-4" style="background: #343a40; color: white;">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <small class="d-block">МКУ "Управление образования Нюрбинского района"</small>
                    <small class="text-muted">Редактирование оценок образовательных учреждений</small>
                </div>
                <div class="col-md-6 text-md-end">
                    <small>
                        <i class="fas fa-copyright me-1"></i> Все права защищены 
                        <i class="fas fa-shield-alt mx-1"></i> 2025 год 
                        by Эдуард Федоров
                    </small>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Валидация формы
        document.getElementById('ratingForm').addEventListener('submit', function(e) {
            const scoreInput = this.querySelector('input[name="score"]');
            const score = parseFloat(scoreInput.value);
            
            if (isNaN(score) || score < 0 || score > 100) {
                e.preventDefault();
                alert('Балл должен быть числом от 0 до 100');
                scoreInput.focus();
                return false;
            }
            
            // Показываем индикатор загрузки
            const submitBtn = this.querySelector('button[type="submit"]');
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Сохранение...';
            submitBtn.disabled = true;
        });

        // Валидация в реальном времени
        const scoreInput = document.querySelector('input[name="score"]');
        scoreInput.addEventListener('blur', function() {
            const score = parseFloat(this.value);
            if (isNaN(score) || score < 0 || score > 100) {
                this.classList.add('is-invalid');
            } else {
                this.classList.remove('is-invalid');
            }
        });
    </script>
</body>
</html>