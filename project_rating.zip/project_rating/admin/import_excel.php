<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Проверка авторизации
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

include_once '../config/database.php';
include_once '../models/Rating.php';

$success = null;
$error = null;
$import_stats = null;

try {
    $database = new Database();
    $db = $database->getConnection();
    $rating = new Rating($db);

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['excel_file'])) {
        $file = $_FILES['excel_file'];
        
        // Проверка файла
        if ($file['error'] !== UPLOAD_ERR_OK) {
            throw new Exception('Ошибка загрузки файла: ' . $file['error']);
        }
        
        // Проверка расширения
        $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($file_ext, ['xlsx', 'xls', 'csv'])) {
            throw new Exception('Допустимы только файлы Excel (.xlsx, .xls) и CSV');
        }
        
        // Временная загрузка файла
        $upload_dir = '../uploads/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        $filename = uniqid() . '_' . $file['name'];
        $filepath = $upload_dir . $filename;
        
        if (!move_uploaded_file($file['tmp_name'], $filepath)) {
            throw new Exception('Не удалось сохранить файл');
        }
        
        // Импорт данных
        $import_stats = $rating->importFromExcel($filepath, $file_ext);
        $success = "Данные успешно импортированы!";
        
        // Удаляем временный файл
        unlink($filepath);
    }
    
} catch (Exception $e) {
    $error = "Ошибка импорта: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Импорт Excel - Панель управления</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-file-import me-2"></i>Импорт данных из Excel
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-arrow-left me-1"></i>Назад в панель
                </a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <?php if ($success): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <i class="fas fa-check-circle me-2"></i><?= $success ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <i class="fas fa-exclamation-triangle me-2"></i><?= $error ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- Форма импорта -->
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-header bg-white">
                        <h4 class="mb-0">
                            <i class="fas fa-upload me-2 text-primary"></i>Загрузка файла
                        </h4>
                    </div>
                    <div class="card-body">
                        <form method="POST" enctype="multipart/form-data" id="importForm">
                            <div class="mb-4">
                                <label class="form-label fw-semibold">Выберите файл для импорта</label>
                                <input type="file" name="excel_file" class="form-control" accept=".xlsx,.xls,.csv" required>
                                <div class="form-text">
                                    Поддерживаемые форматы: Excel (.xlsx, .xls), CSV
                                </div>
                            </div>
                            
                            <div class="mb-4">
                                <label class="form-label fw-semibold">Учебный год</label>
                                <select name="academic_year" class="form-select" required>
                                    <option value="2024-2025">2024-2025</option>
                                    <option value="2025-2026" selected>2025-2026</option>
                                </select>
                            </div>

                            <div class="alert alert-info">
                                <h6 class="alert-heading">
                                    <i class="fas fa-info-circle me-2"></i>Требования к файлу:
                                </h6>
                                <ul class="mb-0">
                                    <li>Файл должен содержать колонки: Школа, Критерий, Балл</li>
                                    <li>Первая строка - заголовки колонок</li>
                                    <li>Названия школ должны соответствовать базе данных</li>
                                    <li>Баллы должны быть числовыми значениями от 0 до 100</li>
                                </ul>
                            </div>

                            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <button type="submit" class="btn btn-primary btn-lg">
                                    <i class="fas fa-upload me-2"></i>Начать импорт
                                </button>
                                <a href="dashboard.php" class="btn btn-secondary btn-lg">
                                    <i class="fas fa-times me-2"></i>Отмена
                                </a>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Статистика импорта -->
                <?php if ($import_stats): ?>
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-white">
                            <h5 class="mb-0">
                                <i class="fas fa-chart-bar me-2 text-success"></i>Результаты импорта
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="row text-center">
                                <div class="col-md-3 mb-3">
                                    <div class="border rounded p-3 bg-success text-white">
                                        <i class="fas fa-check-circle fa-2x mb-2"></i>
                                        <h4><?= $import_stats['imported'] ?? 0 ?></h4>
                                        <p class="mb-0">Успешно импортировано</p>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <div class="border rounded p-3 bg-warning text-dark">
                                        <i class="fas fa-exclamation-triangle fa-2x mb-2"></i>
                                        <h4><?= $import_stats['skipped'] ?? 0 ?></h4>
                                        <p class="mb-0">Пропущено</p>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <div class="border rounded p-3 bg-info text-white">
                                        <i class="fas fa-school fa-2x mb-2"></i>
                                        <h4><?= $import_stats['schools_count'] ?? 0 ?></h4>
                                        <p class="mb-0">Обработано школ</p>
                                    </div>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <div class="border rounded p-3 bg-primary text-white">
                                        <i class="fas fa-list-alt fa-2x mb-2"></i>
                                        <h4><?= $import_stats['criteria_count'] ?? 0 ?></h4>
                                        <p class="mb-0">Критериев</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Шаблон файла -->
                <div class="card border-0 shadow-sm mt-4">
                    <div class="card-header bg-white">
                        <h5 class="mb-0">
                            <i class="fas fa-download me-2 text-info"></i>Шаблон файла
                        </h5>
                    </div>
                    <div class="card-body">
                        <p>Скачайте шаблон для правильного форматирования данных:</p>
                        <div class="d-flex gap-2">
                            <a href="../templates/import_template.xlsx" class="btn btn-success">
                                <i class="fas fa-file-excel me-2"></i>Скачать шаблон Excel
                            </a>
                            <a href="../templates/import_template.csv" class="btn btn-info">
                                <i class="fas fa-file-csv me-2"></i>Скачать шаблон CSV
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer mt-5 py-4" style="background: #343a40; color: white;">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <small class="d-block">МКУ "Управление образования Нюрбинского района"</small>
                    <small class="text-muted">Система массового импорта данных</small>
                </div>
                <div class="col-md-6 text-md-end">
                    <small>
                        <i class="fas fa-copyright me-1"></i> Все права защищены 
                        <i class="fas fa-shield-alt mx-1"></i> 2025 год 
                        by Эдуард Федоров
                    </small>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Обработка формы
        document.getElementById('importForm').addEventListener('submit', function(e) {
            const fileInput = this.querySelector('input[type="file"]');
            const file = fileInput.files[0];
            
            if (file) {
                const fileSize = file.size / 1024 / 1024; // в MB
                if (fileSize > 10) {
                    e.preventDefault();
                    alert('Файл слишком большой. Максимальный размер: 10MB');
                    return false;
                }
            }
            
            // Показываем индикатор загрузки
            const submitBtn = this.querySelector('button[type="submit"]');
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Импорт...';
            submitBtn.disabled = true;
        });
    </script>
</body>
</html>