<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Проверка авторизации
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

// Для PDF экспорта потребуется библиотека вроде TCPDF или Dompdf
// Здесь приведем упрощенный вариант с перенаправлением

header("Location: analytics.php?message=" . urlencode("PDF экспорт временно недоступен. Используйте Excel экспорт."));
exit;

// В реальной реализации здесь был бы код для генерации PDF
?>