<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Проверка авторизации
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

include_once '../config/database.php';
include_once '../models/School.php';

$success = null;
$error = null;

try {
    $database = new Database();
    $db = $database->getConnection();
    $school = new School($db);

    // Обработка формы добавления школы
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = $_POST['name'] ?? '';
        $district_id = $_POST['district_id'] ?? 1; // По умолчанию Нюрбинский район
        $type = $_POST['type'] ?? '';
        $address = $_POST['address'] ?? '';
        $director = $_POST['director'] ?? '';
        $phone = $_POST['phone'] ?? '';
        $email = $_POST['email'] ?? '';
        $website = $_POST['website'] ?? '';
        $description = $_POST['description'] ?? '';

        // Валидация
        if (empty($name) || empty($type)) {
            $error = "Название школы и тип обязательны для заполнения";
        } else {
            // Добавляем школу
            $result = $school->createSchool([
                'name' => $name,
                'district_id' => $district_id,
                'type' => $type,
                'address' => $address,
                'director' => $director,
                'phone' => $phone,
                'email' => $email,
                'website' => $website,
                'description' => $description
            ]);

            if ($result) {
                $success = "Школа успешно добавлена!";
                // Очищаем поля формы
                $_POST = [];
            } else {
                $error = "Ошибка при добавлении школы";
            }
        }
    }

} catch (Exception $e) {
    $error = "Ошибка: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Добавить школу - Панель управления</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-plus me-2"></i>Добавить школу
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-arrow-left me-1"></i>Назад в панель
                </a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <?php if ($success): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <i class="fas fa-check-circle me-2"></i><?= $success ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <i class="fas fa-exclamation-triangle me-2"></i><?= $error ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white">
                        <h4 class="mb-0">
                            <i class="fas fa-school me-2 text-primary"></i>Добавление нового образовательного учреждения
                        </h4>
                    </div>
                    <div class="card-body">
                        <form method="POST" id="schoolForm">
                            <div class="row g-3">
                                <!-- Основная информация -->
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Название школы <span class="text-danger">*</span></label>
                                    <input type="text" name="name" class="form-control" 
                                           value="<?= htmlspecialchars($_POST['name'] ?? '') ?>" 
                                           required maxlength="255">
                                </div>
                                
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Тип учреждения <span class="text-danger">*</span></label>
                                    <select name="type" class="form-select" required>
                                        <option value="">Выберите тип...</option>
                                        <option value="Средняя общеобразовательная школа" <?= ($_POST['type'] ?? '') == 'Средняя общеобразовательная школа' ? 'selected' : '' ?>>Средняя общеобразовательная школа</option>
                                        <option value="Основная общеобразовательная школа" <?= ($_POST['type'] ?? '') == 'Основная общеобразовательная школа' ? 'selected' : '' ?>>Основная общеобразовательная школа</option>
                                        <option value="Начальная школа" <?= ($_POST['type'] ?? '') == 'Начальная школа' ? 'selected' : '' ?>>Начальная школа</option>
                                        <option value="Гимназия" <?= ($_POST['type'] ?? '') == 'Гимназия' ? 'selected' : '' ?>>Гимназия</option>
                                        <option value="Лицей" <?= ($_POST['type'] ?? '') == 'Лицей' ? 'selected' : '' ?>>Лицей</option>
                                        <option value="Центр образования" <?= ($_POST['type'] ?? '') == 'Центр образования' ? 'selected' : '' ?>>Центр образования</option>
                                    </select>
                                </div>

                                <!-- Контактная информация -->
                                <div class="col-12">
                                    <label class="form-label fw-semibold">Адрес</label>
                                    <input type="text" name="address" class="form-control" 
                                           value="<?= htmlspecialchars($_POST['address'] ?? '') ?>" 
                                           maxlength="255">
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Директор</label>
                                    <input type="text" name="director" class="form-control" 
                                           value="<?= htmlspecialchars($_POST['director'] ?? '') ?>" 
                                           maxlength="100">
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Телефон</label>
                                    <input type="tel" name="phone" class="form-control" 
                                           value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>" 
                                           maxlength="20">
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Email</label>
                                    <input type="email" name="email" class="form-control" 
                                           value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" 
                                           maxlength="100">
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Веб-сайт</label>
                                    <input type="url" name="website" class="form-control" 
                                           value="<?= htmlspecialchars($_POST['website'] ?? '') ?>" 
                                           maxlength="255" placeholder="https://">
                                </div>

                                <!-- Дополнительная информация -->
                                <div class="col-12">
                                    <label class="form-label fw-semibold">Описание</label>
                                    <textarea name="description" class="form-control" rows="4" 
                                              maxlength="500" placeholder="Краткое описание школы..."><?= htmlspecialchars($_POST['description'] ?? '') ?></textarea>
                                    <div class="form-text">Максимум 500 символов</div>
                                </div>

                                <!-- Скрытые поля -->
                                <input type="hidden" name="district_id" value="1">

                                <!-- Кнопки -->
                                <div class="col-12">
                                    <hr>
                                    <div class="d-flex justify-content-between">
                                        <button type="submit" class="btn btn-primary btn-lg">
                                            <i class="fas fa-save me-2"></i>Добавить школу
                                        </button>
                                        <a href="dashboard.php" class="btn btn-secondary btn-lg">
                                            <i class="fas fa-times me-2"></i>Отмена
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Подсказки -->
                <div class="card border-0 shadow-sm mt-4">
                    <div class="card-header bg-white">
                        <h5 class="mb-0">
                            <i class="fas fa-info-circle me-2 text-info"></i>Информация
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h6>Обязательные поля:</h6>
                                <ul class="mb-0">
                                    <li>Название школы</li>
                                    <li>Тип учреждения</li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <h6>Рекомендации:</h6>
                                <ul class="mb-0">
                                    <li>Указывайте полное официальное название</li>
                                    <li>Проверяйте корректность контактных данных</li>
                                    <li>Заполняйте описание для лучшей идентификации</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer mt-5 py-4" style="background: #343a40; color: white;">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <small class="d-block">МКУ "Управление образования Нюрбинского района"</small>
                    <small class="text-muted">Реестр образовательных учреждений</small>
                </div>
                <div class="col-md-6 text-md-end">
                    <small>
                        <i class="fas fa-copyright me-1"></i> Все права защищены 
                        <i class="fas fa-shield-alt mx-1"></i> 2025 год 
                        by Эдуард Федоров
                    </small>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Валидация формы
        document.getElementById('schoolForm').addEventListener('submit', function(e) {
            const name = this.querySelector('input[name="name"]').value.trim();
            const type = this.querySelector('select[name="type"]').value;
            
            if (!name) {
                e.preventDefault();
                alert('Пожалуйста, введите название школы');
                return false;
            }
            
            if (!type) {
                e.preventDefault();
                alert('Пожалуйста, выберите тип учреждения');
                return false;
            }
            
            // Показываем индикатор загрузки
            const submitBtn = this.querySelector('button[type="submit"]');
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Добавление...';
            submitBtn.disabled = true;
        });
    </script>
</body>
</html>