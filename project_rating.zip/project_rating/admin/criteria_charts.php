<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Аналитика</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">Аналитика</a>
        </div>
    </nav>
    <div class="container mt-4">
        <div class="card">
            <div class="card-body text-center py-5">
                <h3>Аналитика в разработке</h3>
                <p class="text-muted">Диаграммы и графики появятся здесь скоро</p>
                <a href="dashboard.php" class="btn btn-primary">Назад</a>
            </div>
        </div>
    </div>
</body>
</html>