<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Проверка авторизации
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

include_once '../config/database.php';
include_once '../models/Rating.php';

try {
    $database = new Database();
    $db = $database->getConnection();
    $rating = new Rating($db);

    $academic_year = $_GET['academic_year'] ?? '2025-2026';
    $district_id = 1; // Нюрбинский район

    // Получаем данные для экспорта
    $filters = [
        'academic_year' => $academic_year,
        'district_id' => $district_id
    ];

    $export_data = $rating->getExportData($filters);

    // Устанавливаем заголовки для скачивания Excel файла
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment; filename="reiting_shkol_' . $academic_year . '_' . date('Y-m-d') . '.xls"');
    header('Pragma: no-cache');
    header('Expires: 0');

    // Выводим данные в формате Excel
    echo "<html>";
    echo "<head>";
    echo "<meta charset='UTF-8'>";
    echo "<style>
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid black; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; font-weight: bold; }
        .number { text-align: right; }
    </style>";
    echo "</head>";
    echo "<body>";
    
    echo "<h2>Рейтинг образовательных учреждений Нюрбинского района</h2>";
    echo "<p><strong>Учебный год:</strong> " . $academic_year . "</p>";
    echo "<p><strong>Дата формирования:</strong> " . date('d.m.Y H:i') . "</p>";
    
    echo "<table>";
    echo "<thead>";
    echo "<tr>";
    echo "<th>Место</th>";
    echo "<th>Образовательное учреждение</th>";
    echo "<th>Тип учреждения</th>";
    echo "<th>Общий балл</th>";
    echo "<th>Количество оценок</th>";
    echo "<th>Дата последней оценки</th>";
    echo "</tr>";
    echo "</thead>";
    echo "<tbody>";

    $position = 1;
    foreach ($export_data as $row) {
        echo "<tr>";
        echo "<td class='number'>" . $position . "</td>";
        echo "<td>" . htmlspecialchars($row['school_name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['school_type']) . "</td>";
        echo "<td class='number'>" . number_format($row['average_score'], 2) . "</td>";
        echo "<td class='number'>" . $row['rating_count'] . "</td>";
        echo "<td>" . date('d.m.Y', strtotime($row['last_rating_date'])) . "</td>";
        echo "</tr>";
        $position++;
    }

    echo "</tbody>";
    echo "</table>";

    // Добавляем статистику
    echo "<br><br>";
    echo "<h3>Статистика</h3>";
    echo "<table>";
    echo "<tr><td><strong>Всего школ в рейтинге:</strong></td><td>" . count($export_data) . "</td></tr>";
    echo "<tr><td><strong>Средний балл по району:</strong></td><td>" . 
         (count($export_data) > 0 ? number_format(array_sum(array_column($export_data, 'average_score')) / count($export_data), 2) : '0.00') . 
         "</td></tr>";
    echo "<tr><td><strong>Максимальный балл:</strong></td><td>" . 
         (count($export_data) > 0 ? number_format(max(array_column($export_data, 'average_score')), 2) : '0.00') . 
         "</td></tr>";
    echo "<tr><td><strong>Минимальный балл:</strong></td><td>" . 
         (count($export_data) > 0 ? number_format(min(array_column($export_data, 'average_score')), 2) : '0.00') . 
         "</td></tr>";
    echo "</table>";

    echo "</body>";
    echo "</html>";

    exit;

} catch (Exception $e) {
    // В случае ошибки перенаправляем обратно
    header("Location: analytics.php?error=" . urlencode("Ошибка экспорта: " . $e->getMessage()));
    exit;
}
?>