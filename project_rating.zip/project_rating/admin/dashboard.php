<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Упрощенная проверка авторизации
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

include_once '../config/database.php';
include_once '../models/School.php';
include_once '../models/Rating.php';

// Инициализация переменных
$schools_count = 0;
$total_rated = 0;
$academic_year = '2025-2026';
$overall_rating = null;
$error = null;

try {
    $database = new Database();
    $db = $database->getConnection();
    
    $school = new School($db);
    $rating = new Rating($db);
    
    // Получаем параметры
    $academic_year = $_GET['academic_year'] ?? '2025-2026';
    $filters = [
        'academic_year' => $academic_year,
        'district_id' => 1 // Нюрбинский район
    ];
    
    // Получаем количество школ
    $schools_count = $school->getSchoolsCount(1);
    
    // Пробуем получить рейтинг
    try {
        $overall_rating = $rating->getOverallRating($filters);
        if ($overall_rating) {
            $total_rated = $overall_rating->rowCount();
        }
    } catch (Exception $e) {
        $error = "Ошибка загрузки рейтинга: " . $e->getMessage();
    }
    
} catch (Exception $e) {
    $error = "Ошибка подключения: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель управления - Нюрбинский район</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .stat-card {
            transition: transform 0.2s;
            border: none;
            border-radius: 10px;
        }
        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .nav-card {
            border: none;
            border-radius: 10px;
            transition: all 0.3s;
        }
        .nav-card:hover {
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .footer {
            background: #343a40 !important;
            color: white;
        }
        .table th {
            background-color: #f8f9fa;
        }
        .action-buttons .btn {
            margin: 2px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-school me-2"></i>Панель управления
            </a>
            <div class="navbar-nav ms-auto flex-row">
                <a class="nav-link me-3" href="../index.php" title="На главную страницу">
                    <i class="fas fa-home"></i>
                </a>
                <a class="nav-link me-3" href="analytics.php" title="Аналитика и диаграммы">
                    <i class="fas fa-chart-bar"></i>
                </a>
                <a class="nav-link me-3" href="import_excel.php" title="Импорт данных из Excel">
                    <i class="fas fa-file-import"></i>
                </a>
                <a class="nav-link me-3" href="profile.php" title="Мой профиль">
                    <i class="fas fa-user"></i>
                </a>
                <span class="navbar-text me-3">
                    <i class="fas fa-user me-1"></i><?= $_SESSION['admin_username'] ?? 'Администратор' ?>
                </span>
                <a class="nav-link" href="logout.php" title="Выйти из системы">
                    <i class="fas fa-sign-out-alt"></i>
                </a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if (isset($error)): ?>
            <div class="alert alert-warning alert-dismissible fade show">
                <i class="fas fa-exclamation-triangle me-2"></i>
                <?= $error ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Заголовок -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body py-4">
                        <h3 class="card-title mb-1 text-primary">
                            <i class="fas fa-tachometer-alt me-2"></i>Панель управления
                        </h3>
                        <p class="text-muted mb-0">Рейтинг образовательных учреждений Нюрбинского района</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Фильтры -->
        <div class="card mb-4 border-0 shadow-sm">
            <div class="card-body">
                <h5 class="card-title mb-3">
                    <i class="fas fa-filter me-2 text-primary"></i>Фильтры рейтинга
                </h5>
                <form method="GET" class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Учебный год</label>
                        <select name="academic_year" class="form-select">
                            <option value="2024-2025" <?= $academic_year == '2024-2025' ? 'selected' : '' ?>>2024-2025</option>
                            <option value="2025-2026" <?= $academic_year == '2025-2026' ? 'selected' : '' ?>>2025-2026</option>
                        </select>
                    </div>
                    <div class="col-md-6 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-check me-1"></i>Применить фильтры
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Статистика -->
        <div class="row mb-4">
            <div class="col-md-3 mb-3">
                <div class="card stat-card text-white bg-success">
                    <div class="card-body text-center py-4">
                        <i class="fas fa-school fa-2x mb-3"></i>
                        <h2 class="mb-1"><?= $schools_count ?></h2>
                        <p class="mb-0 opacity-75">Школ в системе</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card stat-card text-white bg-info">
                    <div class="card-body text-center py-4">
                        <i class="fas fa-chart-line fa-2x mb-3"></i>
                        <h2 class="mb-1"><?= $total_rated ?></h2>
                        <p class="mb-0 opacity-75">В рейтинге</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card stat-card text-white bg-warning">
                    <div class="card-body text-center py-4">
                        <i class="fas fa-map-marker-alt fa-2x mb-3"></i>
                        <h2 class="mb-1">Нюрбинский</h2>
                        <p class="mb-0 opacity-75">Район</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card stat-card text-white bg-primary">
                    <div class="card-body text-center py-4">
                        <i class="fas fa-calendar fa-2x mb-3"></i>
                        <h2 class="mb-1"><?= $academic_year ?></h2>
                        <p class="mb-0 opacity-75">Учебный год</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Быстрая навигация -->
        <div class="row mb-4">
            <div class="col-md-3 mb-3">
                <div class="card nav-card h-100 text-center border-primary">
                    <div class="card-body py-4">
                        <i class="fas fa-edit fa-2x text-primary mb-3"></i>
                        <h5 class="text-primary mb-2">Ввод данных</h5>
                        <p class="text-muted mb-3">Добавление оценок школ</p>
                        <a href="add_rating.php" class="btn btn-primary">
                            <i class="fas fa-arrow-right me-1"></i>Перейти
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card nav-card h-100 text-center border-success">
                    <div class="card-body py-4">
                        <i class="fas fa-file-import fa-2x text-success mb-3"></i>
                        <h5 class="text-success mb-2">Импорт Excel</h5>
                        <p class="text-muted mb-3">Массовая загрузка</p>
                        <a href="import_excel.php" class="btn btn-success">
                            <i class="fas fa-arrow-right me-1"></i>Перейти
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card nav-card h-100 text-center border-warning">
                    <div class="card-body py-4">
                        <i class="fas fa-chart-bar fa-2x text-warning mb-3"></i>
                        <h5 class="text-warning mb-2">Аналитика</h5>
                        <p class="text-muted mb-3">Диаграммы и отчеты</p>
                        <a href="analytics.php" class="btn btn-warning">
                            <i class="fas fa-arrow-right me-1"></i>Перейти
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card nav-card h-100 text-center border-info">
                    <div class="card-body py-4">
                        <i class="fas fa-plus fa-2x text-info mb-3"></i>
                        <h5 class="text-info mb-2">Добавить школу</h5>
                        <p class="text-muted mb-3">Новое учреждение</p>
                        <a href="add_school.php" class="btn btn-info">
                            <i class="fas fa-arrow-right me-1"></i>Перейти
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Рейтинг -->
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white py-3">
                <h4 class="mb-0 text-dark">
                    <i class="fas fa-trophy me-2 text-warning"></i>
                    Рейтинг школ
                    <small class="text-muted">(<?= $academic_year ?>)</small>
                </h4>
            </div>
            <div class="card-body p-0">
                <?php if ($total_rated > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th width="80" class="ps-4">Место</th>
                                    <th>Образовательное учреждение</th>
                                    <th width="120" class="text-center">Общий балл</th>
                                    <th width="150" class="text-center">Действия</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $position = 1;
                                while ($row = $overall_rating->fetch(PDO::FETCH_ASSOC)): 
                                    $total_score = $row['average_score'] ?? 0;
                                ?>
                                    <tr>
                                        <td class="ps-4 align-middle">
                                            <?php if ($position == 1): ?>
                                                <span class="badge bg-warning text-dark fs-6 p-2">🥇 1</span>
                                            <?php elseif ($position == 2): ?>
                                                <span class="badge bg-secondary fs-6 p-2">🥈 2</span>
                                            <?php elseif ($position == 3): ?>
                                                <span class="badge bg-danger fs-6 p-2">🥉 3</span>
                                            <?php else: ?>
                                                <span class="badge bg-light text-dark border fs-6"><?= $position ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="align-middle">
                                            <strong class="d-block"><?= htmlspecialchars($row['school_name']) ?></strong>
                                            <small class="text-muted"><?= htmlspecialchars($row['district_name']) ?> район</small>
                                        </td>
                                        <td class="text-center align-middle">
                                            <span class="badge bg-success fs-5 p-2">
                                                <?= number_format($total_score, 1) ?>
                                            </span>
                                        </td>
                                        <td class="text-center align-middle action-buttons">
                                            <a href="../school_detail.php?id=<?= $row['id'] ?>&academic_year=<?= $academic_year ?>" 
                                               class="btn btn-sm btn-outline-primary" 
                                               title="Просмотр деталей"
                                               target="_blank">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="edit_school.php?id=<?= $row['id'] ?>" 
                                               class="btn btn-sm btn-outline-warning" 
                                               title="Редактировать школу">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="school_ratings.php?id=<?= $row['id'] ?>" 
                                               class="btn btn-sm btn-outline-info" 
                                               title="Управление оценками">
                                                <i class="fas fa-chart-bar"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php 
                                    $position++;
                                endwhile; 
                                ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5 text-muted">
                        <i class="fas fa-chart-line fa-3x mb-3 opacity-50"></i>
                        <h5>Рейтинг пока пуст</h5>
                        <p class="mb-4">Добавьте оценки школ, чтобы увидеть рейтинг</p>
                        <div class="d-flex gap-2 justify-content-center">
                            <a href="add_rating.php" class="btn btn-primary">
                                <i class="fas fa-plus me-2"></i>Добавить оценку
                            </a>
                            <a href="import_excel.php" class="btn btn-success">
                                <i class="fas fa-file-import me-2"></i>Импорт из Excel
                            </a>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Информация о системе -->
        <div class="card mt-4 border-0 shadow-sm">
            <div class="card-body">
                <h5 class="card-title mb-3">
                    <i class="fas fa-info-circle me-2 text-primary"></i>Информация о системе
                </h5>
                <div class="row">
                    <div class="col-md-4">
                        <p><strong>Текущий учебный год:</strong> <?= $academic_year ?></p>
                        <p><strong>Район:</strong> Нюрбинский</p>
                    </div>
                    <div class="col-md-4">
                        <p><strong>Количество школ:</strong> <?= $schools_count ?></p>
                        <p><strong>Критериев оценки:</strong> 6</p>
                    </div>
                    <div class="col-md-4">
                        <p><strong>Версия системы:</strong> 2.0</p>
                        <p><strong>Последнее обновление:</strong> <?= date('d.m.Y') ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Футер -->
    <footer class="footer mt-5 py-4">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <small class="d-block">МКУ "Управление образования Нюрбинского района"</small>
                    <small class="text-muted">Официальный рейтинг образовательных учреждений</small>
                </div>
                <div class="col-md-6 text-md-end">
                    <small>
                        <i class="fas fa-copyright me-1"></i> Все права защищены 
                        <i class="fas fa-shield-alt mx-1"></i> 2025 год 
                        by Эдуард Федоров
                    </small>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>