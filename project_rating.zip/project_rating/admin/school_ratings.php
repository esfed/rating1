<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Проверка авторизации
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

include_once '../config/database.php';
include_once '../models/School.php';
include_once '../models/Rating.php';
include_once '../models/Criteria.php';

$school_id = $_GET['id'] ?? '';
$academic_year = $_GET['academic_year'] ?? '2025-2026';
$school_data = null;
$ratings = [];
$criteria_list = [];
$success = null;
$error = null;

try {
    $database = new Database();
    $db = $database->getConnection();
    
    $school = new School($db);
    $rating = new Rating($db);
    $criteria = new Criteria($db);

    // Получаем данные школы
    if ($school_id) {
        $school_data = $school->getSchoolById($school_id);
    }

    // Получаем оценки школы
    if ($school_data) {
        $ratings = $rating->getSchoolRatings($school_id, $academic_year);
        $criteria_list = $criteria->getAllCriteria();
    }

    // Обработка удаления оценки
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_rating'])) {
        $rating_id = $_POST['rating_id'] ?? '';
        
        if ($rating_id) {
            $result = $rating->deleteRating($rating_id);
            if ($result) {
                $success = "Оценка успешно удалена!";
                // Обновляем список оценок
                $ratings = $rating->getSchoolRatings($school_id, $academic_year);
            } else {
                $error = "Ошибка при удалении оценки";
            }
        }
    }

} catch (Exception $e) {
    $error = "Ошибка: " . $e->getMessage();
}

// Если школа не найдена
if (!$school_data) {
    header("Location: dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Управление оценками - Панель управления</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-chart-bar me-2"></i>Управление оценками
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-arrow-left me-1"></i>Назад в панель
                </a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if ($success): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="fas fa-check-circle me-2"></i><?= $success ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="fas fa-exclamation-triangle me-2"></i><?= $error ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Заголовок и информация о школе -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h3 class="card-title text-primary mb-1">
                            <i class="fas fa-school me-2"></i><?= htmlspecialchars($school_data['name']) ?>
                        </h3>
                        <p class="text-muted mb-2">
                            <i class="fas fa-map-marker-alt me-1"></i><?= htmlspecialchars($school_data['address'] ?? 'Адрес не указан') ?>
                        </p>
                        <div class="d-flex flex-wrap gap-3">
                            <span class="badge bg-secondary"><?= htmlspecialchars($school_data['type'] ?? '') ?></span>
                            <span class="badge bg-info"><?= htmlspecialchars($school_data['district_name'] ?? 'Нюрбинский район') ?></span>
                            <span class="badge bg-primary">Учебный год: <?= $academic_year ?></span>
                        </div>
                    </div>
                    <div class="col-md-4 text-md-end">
                        <a href="add_rating.php?school_id=<?= $school_id ?>" class="btn btn-primary me-2">
                            <i class="fas fa-plus me-1"></i>Добавить оценку
                        </a>
                        <a href="../school_detail.php?id=<?= $school_id ?>" class="btn btn-outline-primary" target="_blank">
                            <i class="fas fa-eye me-1"></i>Просмотр
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Фильтры -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body">
                <form method="GET" class="row g-3">
                    <input type="hidden" name="id" value="<?= $school_id ?>">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Учебный год</label>
                        <select name="academic_year" class="form-select" onchange="this.form.submit()">
                            <option value="2024-2025" <?= $academic_year == '2024-2025' ? 'selected' : '' ?>>2024-2025</option>
                            <option value="2025-2026" <?= $academic_year == '2025-2026' ? 'selected' : '' ?>>2025-2026</option>
                        </select>
                    </div>
                    <div class="col-md-6 d-flex align-items-end">
                        <a href="dashboard.php" class="btn btn-secondary w-100">
                            <i class="fas fa-arrow-left me-1"></i>Вернуться к рейтингу
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Статистика -->
        <div class="row mb-4">
            <div class="col-md-3 mb-3">
                <div class="card text-white bg-primary">
                    <div class="card-body text-center py-3">
                        <i class="fas fa-list-alt fa-2x mb-2"></i>
                        <h4 class="mb-1"><?= count($ratings) ?></h4>
                        <p class="mb-0 opacity-75">Всего оценок</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card text-white bg-success">
                    <div class="card-body text-center py-3">
                        <i class="fas fa-calculator fa-2x mb-2"></i>
                        <h4 class="mb-1">
                            <?php
                            $total_score = 0;
                            $count = 0;
                            foreach ($ratings as $rating_item) {
                                $total_score += $rating_item['score'];
                                $count++;
                            }
                            echo $count > 0 ? number_format($total_score / $count, 1) : '0.0';
                            ?>
                        </h4>
                        <p class="mb-0 opacity-75">Средний балл</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card text-white bg-warning">
                    <div class="card-body text-center py-3">
                        <i class="fas fa-trophy fa-2x mb-2"></i>
                        <h4 class="mb-1">
                            <?php
                            $max_score = 0;
                            foreach ($ratings as $rating_item) {
                                if ($rating_item['score'] > $max_score) {
                                    $max_score = $rating_item['score'];
                                }
                            }
                            echo number_format($max_score, 1);
                            ?>
                        </h4>
                        <p class="mb-0 opacity-75">Максимальный балл</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card text-white bg-info">
                    <div class="card-body text-center py-3">
                        <i class="fas fa-percentage fa-2x mb-2"></i>
                        <h4 class="mb-1">
                            <?= count($criteria_list) > 0 ? round((count($ratings) / count($criteria_list)) * 100) : 0 ?>%
                        </h4>
                        <p class="mb-0 opacity-75">Полнота данных</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Таблица оценок -->
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white">
                <h5 class="mb-0">
                    <i class="fas fa-table me-2 text-primary"></i>Оценки школы
                </h5>
            </div>
            <div class="card-body p-0">
                <?php if (!empty($ratings)): ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th width="50" class="ps-4">#</th>
                                    <th>Критерий оценки</th>
                                    <th width="120" class="text-center">Балл</th>
                                    <th width="200">Комментарий</th>
                                    <th width="150" class="text-center">Дата оценки</th>
                                    <th width="120" class="text-center">Действия</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($ratings as $index => $rating_item): ?>
                                    <tr>
                                        <td class="ps-4 align-middle"><?= $index + 1 ?></td>
                                        <td class="align-middle">
                                            <strong><?= htmlspecialchars($rating_item['criteria_name']) ?></strong>
                                            <?php if (!empty($rating_item['criteria_description'])): ?>
                                                <br>
                                                <small class="text-muted"><?= htmlspecialchars($rating_item['criteria_description']) ?></small>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center align-middle">
                                            <span class="badge bg-<?= 
                                                $rating_item['score'] >= 85 ? 'success' : 
                                                ($rating_item['score'] >= 70 ? 'warning' : 'danger') 
                                            ?> fs-6">
                                                <?= number_format($rating_item['score'], 1) ?>
                                            </span>
                                        </td>
                                        <td class="align-middle">
                                            <?php if (!empty($rating_item['comments'])): ?>
                                                <span class="text-muted" title="<?= htmlspecialchars($rating_item['comments']) ?>">
                                                    <?= strlen($rating_item['comments']) > 50 ? 
                                                        substr(htmlspecialchars($rating_item['comments']), 0, 50) . '...' : 
                                                        htmlspecialchars($rating_item['comments']) ?>
                                                </span>
                                            <?php else: ?>
                                                <span class="text-muted">—</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center align-middle">
                                            <small class="text-muted">
                                                <?= date('d.m.Y', strtotime($rating_item['created_at'])) ?>
                                            </small>
                                        </td>
                                        <td class="text-center align-middle">
                                            <div class="btn-group btn-group-sm">
                                                <a href="edit_rating.php?id=<?= $rating_item['id'] ?>" 
                                                   class="btn btn-outline-warning" 
                                                   title="Редактировать оценку">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <form method="POST" class="d-inline" 
                                                      onsubmit="return confirm('Вы уверены, что хотите удалить эту оценку?')">
                                                    <input type="hidden" name="rating_id" value="<?= $rating_item['id'] ?>">
                                                    <button type="submit" name="delete_rating" 
                                                            class="btn btn-outline-danger" 
                                                            title="Удалить оценку">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5 text-muted">
                        <i class="fas fa-chart-bar fa-3x mb-3 opacity-50"></i>
                        <h5>Оценки не найдены</h5>
                        <p class="mb-4">Для этой школы пока нет оценок за выбранный учебный год</p>
                        <div class="d-flex gap-2 justify-content-center">
                            <a href="add_rating.php?school_id=<?= $school_id ?>" class="btn btn-primary">
                                <i class="fas fa-plus me-2"></i>Добавить оценку
                            </a>
                            <a href="import_excel.php" class="btn btn-success">
                                <i class="fas fa-file-import me-2"></i>Импорт из Excel
                            </a>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Отсутствующие критерии -->
        <?php if (!empty($ratings) && !empty($criteria_list)): ?>
            <?php
            $rated_criteria_ids = array_column($ratings, 'criteria_id');
            $missing_criteria = array_filter($criteria_list, function($criterion) use ($rated_criteria_ids) {
                return !in_array($criterion['id'], $rated_criteria_ids);
            });
            ?>
            
            <?php if (!empty($missing_criteria)): ?>
                <div class="card border-0 shadow-sm mt-4">
                    <div class="card-header bg-warning text-dark">
                        <h5 class="mb-0">
                            <i class="fas fa-exclamation-triangle me-2"></i>Отсутствующие оценки
                        </h5>
                    </div>
                    <div class="card-body">
                        <p class="mb-3">Для следующих критериев нет оценок:</p>
                        <div class="row">
                            <?php foreach ($missing_criteria as $criterion): ?>
                                <div class="col-md-6 mb-2">
                                    <div class="d-flex justify-content-between align-items-center border rounded p-2">
                                        <div>
                                            <strong><?= htmlspecialchars($criterion['name']) ?></strong>
                                            <?php if (!empty($criterion['description'])): ?>
                                                <br>
                                                <small class="text-muted"><?= htmlspecialchars($criterion['description']) ?></small>
                                            <?php endif; ?>
                                        </div>
                                        <a href="add_rating.php?school_id=<?= $school_id ?>&criteria_id=<?= $criterion['id'] ?>" 
                                           class="btn btn-sm btn-outline-primary">
                                            <i class="fas fa-plus me-1"></i>Добавить
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <footer class="footer mt-5 py-4" style="background: #343a40; color: white;">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <small class="d-block">МКУ "Управление образования Нюрбинского района"</small>
                    <small class="text-muted">Управление оценками образовательных учреждений</small>
                </div>
                <div class="col-md-6 text-md-end">
                    <small>
                        <i class="fas fa-copyright me-1"></i> Все права защищены 
                        <i class="fas fa-shield-alt mx-1"></i> 2025 год 
                        by Эдуард Федоров
                    </small>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>