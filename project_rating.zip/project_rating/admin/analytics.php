<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Проверка авторизации
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

include_once '../config/database.php';
include_once '../models/School.php';
include_once '../models/Rating.php';

// Инициализация переменных
$academic_year = $_GET['academic_year'] ?? '2025-2026';
$district_id = 1; // Нюрбинский район
$error = null;
$schools_count = 0;
$total_rated = 0;
$rating_data = [];
$criteria_stats = [];

try {
    $database = new Database();
    $db = $database->getConnection();
    
    $school = new School($db);
    $rating = new Rating($db);
    
    // Получаем количество школ
    $schools_count = $school->getSchoolsCount($district_id);
    
    // Получаем данные для диаграмм
    $filters = [
        'academic_year' => $academic_year,
        'district_id' => $district_id
    ];
    
    $overall_rating = $rating->getOverallRating($filters);
    if ($overall_rating) {
        $total_rated = $overall_rating->rowCount();
        $rating_data = $overall_rating->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Временно закомментируем проблемные части
/*
try {
    $criteria_stats = $rating->getCriteriaStatistics($filters);
} catch (Exception $e) {
    // Игнорируем ошибку для таблицы criteria
    $criteria_stats = [];
}
*/

// Используем пустой массив
$criteria_stats = [];
    
} catch (Exception $e) {
    $error = "Ошибка: " . $e->getMessage();
}

// Подготовка данных для диаграмм
$chart_labels = [];
$chart_scores = [];
$chart_colors = [];

foreach ($rating_data as $index => $school) {
    $chart_labels[] = $school['school_name'];
    $chart_scores[] = floatval($school['average_score']);
    
    // Генерация цветов для диаграммы
    $colors = ['#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b', '#858796', '#5a5c69'];
    $chart_colors[] = $colors[$index % count($colors)];
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Аналитика - Панель управления</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .chart-container {
            position: relative;
            height: 300px;
            margin-bottom: 20px;
        }
        .stat-card {
            border: none;
            border-radius: 10px;
            transition: transform 0.2s;
        }
        .stat-card:hover {
            transform: translateY(-2px);
        }
        .nav-card {
            border: none;
            border-radius: 10px;
            transition: all 0.3s;
        }
        .nav-card:hover {
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-chart-bar me-2"></i>Аналитика и диаграммы
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="dashboard.php">
                    <i class="fas fa-arrow-left me-1"></i>Назад в панель
                </a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if ($error): ?>
            <div class="alert alert-warning alert-dismissible fade show">
                <i class="fas fa-exclamation-triangle me-2"></i><?= $error ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Заголовок и фильтры -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-body py-4">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <h3 class="card-title mb-1 text-primary">
                                    <i class="fas fa-chart-pie me-2"></i>Аналитика рейтинга
                                </h3>
                                <p class="text-muted mb-0">Визуализация данных образовательных учреждений</p>
                            </div>
                            <div class="col-md-6">
                                <form method="GET" class="row g-2">
                                    <div class="col-md-8">
                                        <label class="form-label fw-semibold">Учебный год</label>
                                        <select name="academic_year" class="form-select">
                                            <option value="2024-2025" <?= $academic_year == '2024-2025' ? 'selected' : '' ?>>2024-2025</option>
                                            <option value="2025-2026" <?= $academic_year == '2025-2026' ? 'selected' : '' ?>>2025-2026</option>
                                        </select>
                                    </div>
                                    <div class="col-md-4 d-flex align-items-end">
                                        <button type="submit" class="btn btn-primary w-100">
                                            <i class="fas fa-filter me-1"></i>Применить
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Статистика -->
        <div class="row mb-4">
            <div class="col-md-3 mb-3">
                <div class="card stat-card text-white bg-primary">
                    <div class="card-body text-center py-4">
                        <i class="fas fa-school fa-2x mb-3"></i>
                        <h2 class="mb-1"><?= $schools_count ?></h2>
                        <p class="mb-0 opacity-75">Всего школ</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card stat-card text-white bg-success">
                    <div class="card-body text-center py-4">
                        <i class="fas fa-chart-line fa-2x mb-3"></i>
                        <h2 class="mb-1"><?= $total_rated ?></h2>
                        <p class="mb-0 opacity-75">В рейтинге</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card stat-card text-white bg-warning">
                    <div class="card-body text-center py-4">
                        <i class="fas fa-percentage fa-2x mb-3"></i>
                        <h2 class="mb-1"><?= $schools_count > 0 ? round(($total_rated / $schools_count) * 100) : 0 ?>%</h2>
                        <p class="mb-0 opacity-75">Охват</p>
                    </div>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="card stat-card text-white bg-info">
                    <div class="card-body text-center py-4">
                        <i class="fas fa-calendar fa-2x mb-3"></i>
                        <h2 class="mb-1"><?= $academic_year ?></h2>
                        <p class="mb-0 opacity-75">Учебный год</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Диаграммы -->
        <div class="row mb-4">
            <!-- Столбчатая диаграмма -->
            <div class="col-lg-8 mb-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-white">
                        <h5 class="mb-0">
                            <i class="fas fa-chart-bar me-2 text-primary"></i>
                            Рейтинг школ по баллам
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="chart-container">
                            <canvas id="barChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Круговая диаграмма -->
            <div class="col-lg-4 mb-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-white">
                        <h5 class="mb-0">
                            <i class="fas fa-chart-pie me-2 text-success"></i>
                            Распределение оценок
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="chart-container">
                            <canvas id="pieChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Статистика по критериям -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white">
                        <h5 class="mb-0">
                            <i class="fas fa-list-alt me-2 text-warning"></i>
                            Статистика по критериям оценки
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($criteria_stats)): ?>
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Критерий</th>
                                            <th class="text-center">Средний балл</th>
                                            <th class="text-center">Максимальный балл</th>
                                            <th class="text-center">Минимальный балл</th>
                                            <th class="text-center">Количество оценок</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($criteria_stats as $criterion): ?>
                                            <tr>
                                                <td>
                                                    <strong><?= htmlspecialchars($criterion['criterion_name']) ?></strong>
                                                </td>
                                                <td class="text-center">
                                                    <span class="badge bg-primary fs-6">
                                                        <?= number_format($criterion['avg_score'], 2) ?>
                                                    </span>
                                                </td>
                                                <td class="text-center">
                                                    <span class="badge bg-success"><?= $criterion['max_score'] ?></span>
                                                </td>
                                                <td class="text-center">
                                                    <span class="badge bg-danger"><?= $criterion['min_score'] ?></span>
                                                </td>
                                                <td class="text-center">
                                                    <span class="badge bg-secondary"><?= $criterion['rating_count'] ?></span>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-4 text-muted">
                                <i class="fas fa-chart-bar fa-3x mb-3 opacity-50"></i>
                                <h5>Нет данных для отображения</h5>
                                <p>Добавьте оценки школ, чтобы увидеть статистику</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Топ-5 школ -->
        <div class="row">
            <div class="col-md-6 mb-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-white">
                        <h5 class="mb-0">
                            <i class="fas fa-trophy me-2 text-warning"></i>
                            Топ-5 школ
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php if ($total_rated > 0): ?>
                            <div class="list-group list-group-flush">
                                <?php for ($i = 0; $i < min(5, count($rating_data)); $i++): ?>
                                    <div class="list-group-item d-flex justify-content-between align-items-center">
                                        <div>
                                            <?php if ($i == 0): ?>
                                                <span class="badge bg-warning text-dark me-2">🥇</span>
                                            <?php elseif ($i == 1): ?>
                                                <span class="badge bg-secondary me-2">🥈</span>
                                            <?php elseif ($i == 2): ?>
                                                <span class="badge bg-danger me-2">🥉</span>
                                            <?php else: ?>
                                                <span class="badge bg-light text-dark me-2"><?= $i + 1 ?></span>
                                            <?php endif; ?>
                                            <?= htmlspecialchars($rating_data[$i]['school_name']) ?>
                                        </div>
                                        <span class="badge bg-success fs-6">
                                            <?= number_format($rating_data[$i]['average_score'], 1) ?>
                                        </span>
                                    </div>
                                <?php endfor; ?>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-4 text-muted">
                                <i class="fas fa-trophy fa-2x mb-3 opacity-50"></i>
                                <p>Нет данных для рейтинга</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Экспорт данных -->
            <div class="col-md-6 mb-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-white">
                        <h5 class="mb-0">
                            <i class="fas fa-download me-2 text-info"></i>
                            Экспорт данных
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-12">
                                <div class="card nav-card h-100 text-center border-primary">
                                    <div class="card-body py-4">
                                        <i class="fas fa-file-excel fa-2x text-success mb-3"></i>
                                        <h5 class="text-success mb-2">Excel отчет</h5>
                                        <p class="text-muted mb-3">Полный рейтинг в Excel</p>
                                        <a href="export_excel.php?academic_year=<?= $academic_year ?>" class="btn btn-success">
                                            <i class="fas fa-download me-2"></i>Скачать Excel
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="card nav-card h-100 text-center border-warning">
                                    <div class="card-body py-4">
                                        <i class="fas fa-file-pdf fa-2x text-danger mb-3"></i>
                                        <h5 class="text-danger mb-2">PDF отчет</h5>
                                        <p class="text-muted mb-3">Детальный отчет в PDF</p>
                                        <a href="export_pdf.php?academic_year=<?= $academic_year ?>" class="btn btn-danger">
                                            <i class="fas fa-download me-2"></i>Скачать PDF
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer mt-5 py-4" style="background: #343a40; color: white;">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <small class="d-block">МКУ "Управление образования Нюрбинского района"</small>
                    <small class="text-muted">Аналитическая панель рейтинга</small>
                </div>
                <div class="col-md-6 text-md-end">
                    <small>
                        <i class="fas fa-copyright me-1"></i> Все права защищены 
                        <i class="fas fa-shield-alt mx-1"></i> 2025 год 
                        by Эдуард Федоров
                    </small>
                </div>
            </div>
        </div>
    </footer>

    <script>
        // Столбчатая диаграмма
        const barCtx = document.getElementById('barChart').getContext('2d');
        const barChart = new Chart(barCtx, {
            type: 'bar',
            data: {
                labels: <?= json_encode($chart_labels) ?>,
                datasets: [{
                    label: 'Общий балл',
                    data: <?= json_encode($chart_scores) ?>,
                    backgroundColor: <?= json_encode($chart_colors) ?>,
                    borderColor: '#4e73df',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        title: {
                            display: true,
                            text: 'Баллы'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Образовательные учреждения'
                        }
                    }
                }
            }
        });

        // Круговая диаграмма распределения оценок
        const pieCtx = document.getElementById('pieChart').getContext('2d');
        
        // Создаем группы оценок
        const scores = <?= json_encode($chart_scores) ?>;
        let excellent = 0, good = 0, satisfactory = 0, poor = 0;
        
        scores.forEach(score => {
            if (score >= 85) excellent++;
            else if (score >= 70) good++;
            else if (score >= 50) satisfactory++;
            else poor++;
        });

        const pieChart = new Chart(pieCtx, {
            type: 'pie',
            data: {
                labels: ['Отлично (85+)', 'Хорошо (70-84)', 'Удовлетворительно (50-69)', 'Неудовлетворительно (<50)'],
                datasets: [{
                    data: [excellent, good, satisfactory, poor],
                    backgroundColor: ['#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b'],
                    hoverBackgroundColor: ['#17a673', '#2c9faf', '#dda20a', '#be2617']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>